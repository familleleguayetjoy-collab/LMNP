# Moteur LMNP S2A — codage réel (cœur déterministe)

Début de l'implémentation réelle, séparée de la maquette de démonstration
(`index.html`). Ici, **tout ce qui touche aux montants est du code testé**,
jamais de l'IA. L'IA n'intervient que sur deux tâches, et seulement pour
*proposer* (l'humain valide) : lire une facture, proposer un compte sur un
fournisseur inconnu.

## Ce qui marche déjà (testé, `python3 tool/tests/selftest.py` → 232 contrôles OK)

| Module | Rôle | État |
|---|---|---|
| `normalize.py` | Normalisation des libellés + **parsing robuste des montants FR** | ✅ |
| `fec.py` | Lecture du FEC (délimiteur `|`/tab/`;`, encodage, débit/crédit ou montant+sens) | ✅ **éprouvé sur le vrai FEC (684 lignes)** |
| `dico.py` | Dictionnaire client + détection des imputations multiples N-1 | ✅ **+ exclusion des À-Nouveaux / amortissements (bug corrigé, voir + bas)** |
| `codage.py` | Règles de codage. Ne remonte que **immo / inconnu / multi**. Respecte une ligne **déjà codée** à l'export bancaire. **`adapter_au_plan` : le FEC du dossier fait loi** — un compte de règle générique est adapté au sous-compte réel du dossier (606→606100), et sur plusieurs candidats (614100/614200) c'est « à choisir » (souvent = quel bien) | ✅ |
| `rapprochement.py` | Rapprochement facture↔banque, écarts, manquants, **anti-doublon**, **factures sans banque → OD (108)** | ✅ |
| `quadra.py` | **Lecture + export Quadratus ASCII (251 car., contrepartie en ligne)** | ✅ **calibré au format RÉEL du cabinet, aller-retour octet à octet vérifié** |
| `biens.py` | **Suivi par bien : sous-comptes (614/6141), routage par adresse OCR, mapping sauvegardé + revue N-1** | ✅ |
| `pipeline.py` | **Orchestrateur** : `ingerer()` (OCR des seules pièces neuves) + `traiter_dossier()` (codage → adaptation plan → rapprochement → résidu IA en 1 appel → Quadra + à-réclamer) + `traiter_lot()` (tous les dossiers d'un coup + **tableau de bord** : statut, taux d'auto-codage, coût IA estimé) | ✅ |
| `controles.py` | **Revue analytique N vs N-1** : charge récurrente disparue, montant qui double, doublon, loyers incomplets — signale, ne corrige jamais | ✅ |
| `relances.py` | **Relance client** des pièces manquantes avec **verrou de certitude** (certain → mail auto ; ponctuel/inconnu → à vérifier). Génère le brouillon ; l'envoi = connecteur mail | ✅ |
| `sources.py` | **Ingestion** : interface `SourcePieces` + `DossierLocal` (dossier disque) | ✅ |
| `drive.py` | **Connecteur Google Drive** : compte de service, portée `drive.readonly` **uniquement**, aucune méthode d'écriture sur la source, descente `client/année/`, empreinte = sha256 du CONTENU téléchargé (pas le md5 de Drive, que le manifeste ne parle pas). Dépendance Google optionnelle et **non silencieuse** | ✅ testé sur un Drive bouché ; à éprouver sur le Drive réel |
| `manifeste.py` | **Idempotence** : suivi des pièces déjà traitées par empreinte sha256 (un fichier renommé n'est pas re-OCR). JSON, sans contenu client | ✅ |
| `ocr.py` | Contrat vision (les 3 pièges des vraies factures) | ✅ contrat ; implémentation réelle dans `client_anthropic.py` |
| `ia.py` | **Couche IA** : contrat JSON entrée/sortie, résidu ambigu envoyé **en lot**, garde-fous (montant jamais touché, rien validé auto) | ✅ **interface + plomberie testées** |
| `client_anthropic.py` | **`ClientIA` réel sur l'API Claude** (Haiku 4.5 par défaut, escalade Sonnet 5). Clé lue dans `ANTHROPIC_API_KEY`. Import paresseux → le cœur reste stdlib | ✅ **câblé et testé en réel** (résolution d'ambiguïté + OCR) |
| `classement.py` | **Classement d'entrée** : avant toute extraction, la pièce est rangée dans une des 9 catégories. Un devis, un bon de commande, un document illisible ou incohérent (HT + TVA ≠ TTC) **ne devient jamais une facture** ; il ressort en rejet motivé | ✅ |
| `pretraitement.py` | Réduction des images avant envoi (côté max 1500 px, JPEG 80) : moins de jetons, même lisibilité. Pillow / pypdfium2 optionnels — leur absence est **signalée**, jamais silencieuse, et un taux de repli > 5 % déclenche une alerte | ✅ |
| `cout.py` | **Coût réel mesuré** sur `response.usage` (et non estimé) : jetons entrée/sortie, écriture et lecture de cache, conversion en euros, alerte au-delà du plafond par dossier, taux de réutilisation du préfixe | ✅ |
| `rangement.py` | **Plan de classement des pièces** dans « Documents générés par l'application » : un dossier par **mois de règlement**, scindé en `Traité` / `En attente de traitement`. Aucune pièce n'est perdue ; un mois déduit de la date de facture est marqué comme estimé | ✅ |
| `excel.py` | Journal de banque en `.xlsx` (sans dépendance) : opérations triées par date, montants modifiables avant import, un journal par compte 512 du dossier | ✅ |

## Cas comptables traités (demandés par le cabinet)

- **Ligne bancaire déjà pré-codée** (le logiciel a déjà affecté le compte) : on
  fait confiance, on ne recode pas, ce n'est pas remonté à l'humain ; on
  rapproche quand même la facture et on détecte les **doublons**.
- **Facture sans ligne bancaire** (banque incomplète / paiement hors banque) :
  écriture au **journal OD**, contrepartie **108** (compte de l'exploitant).
- **Plusieurs biens** (LMNP/LMP/SCI) : **sous-comptes par bien** (614 Bonaparte,
  6141 Lépante). Le mapping compte↔bien est proposé depuis le FEC N-1,
  **sauvegardé**, **modifiable**, et **revu** d'une année sur l'autre (diff).
  L'**adresse lue sur la facture** route vers le bon bien.
- **Profil BNC / médecin** : recettes mises de côté (pas de justificatif
  attendu), récurrent pré-affecté (à brancher côté règles selon le profil).

### Durcissement LMNP — 30 cas à risque anticipés et traités (section 20 des tests)

Revue préventive des pièges propres au meublé. Chaque cas ci-dessous a un
contrôle de non-régression :

**Recettes piégeuses** — dépôt de garantie reçu → **165 (dette, jamais 706)**,
même quand le libellé contient « loyer » ; APL/CAF → loyer 706 (pas une
subvention) ; recette **Airbnb/Booking** → 706 mais signalée « montant net de
commission, ventiler 622 » ; avoir/remboursement reçu → à rattacher.

**Emprunt** — échéance de prêt **sans** tableau d'amortissement → remontée pour
ventiler 661/164 (jamais passée à 100 % en charge) ; **avec** tableau →
ventilée auto. Garde-fou : une banque nommée « CREDIT MUTUEL/AGRICOLE » n'est
pas confondue avec un prêt.

**Charges récurrentes** — taxe foncière → 63512 ; CFE → 63511 ; honoraires
(gestion/agence/comptable) → 622 ; assurance PNO/GLI/emprunteur → 616 ; charges
de copropriété courantes → 614 ; eau/assainissement, gaz → 606 ; frais de
notaire → à trancher (immo vs charge sur option). « Syndic **honoraires** » →
622 (l'ordre honoraires-avant-copro évite le faux positif).

**TVA para-hôtelier** — `coder(..., assujetti_tva=True)` : sur un dossier
assujetti (meublé de tourisme classé, SCI à l'IS…), on **ne poste pas le TTC en
charge** — l'opération est remontée pour saisie HT + TVA déductible (44566). Par
défaut `False` (LMNP non assujetti, ~90 %).

**Montants** — signe négatif **en fin** de ligne (`120,00-`), symbole € et
espace insécable, signe en tête, parenthèses comptables `(89,90)`.

**Dates** — ISO, `JJ/MM/AAAA`, `AAAAMMJJ`, **n° de série Excel**, `datetime`
(`parse_date`, pour les relevés bancaires hétérogènes).

**Quadra (avant import)** — montant > 12 chiffres **rejeté** (jamais tronqué en
silence) ; libellé nettoyé (accents/caractères spéciaux) ; `comptes_absents`
signale un compte absent du plan comptable du dossier avant que Quadra ne
rejette le fichier.

### Rapprochement — cas particuliers (le rapprochement JUSTIFIE, il ne décide pas la compta)

- **1 règlement ↔ plusieurs factures** (`associer_factures`) : total des
  justificatifs comparé au mouvement ; « exact » ou « à vérifier ».
- **1 facture ↔ plusieurs règlements** & **règlement partiel**
  (`associer_reglements`) : conserve la relation, empêche de réutiliser un
  mouvement, calcule le reste ; statut solde / partiel / écart.
- **Virement interne** entre 2 comptes (`detecter_virements_internes`) : même
  montant, sens opposé, date proche, comptes différents → **proposé** (jamais
  validé auto ; rien si ambigu).
- **Dépense personnelle** (`marquer_perso`) : contrepartie 108 ou 455 selon la
  forme — jamais conclu sur le seul fournisseur, toujours à confirmer.
- **Doublon de justificatif** (`doublons_factures`) : hash (même fichier
  renommé) ou (n°, fournisseur, date, TTC, HT). Doublon bancaire (`doublons`).
- **Chèque / espèces** (`rapprocher`, champ `mode`) : fenêtre de dates élargie
  pour les chèques ; espèces = pas d'anomalie si aucune ligne bancaire.
- **Écriture déjà dans le FEC** (`chercher_dans_fec`) : anti double
  comptabilisation à l'import d'un FEC couvrant déjà une partie de la période.

## Éprouvé sur les vrais fichiers du cabinet

- **Quadra ASCII (dossier DUMDUM)** : format entièrement décodé et **ré-écrit à
  l'identique** (95/95 lignes M, au caractère près). Enregistrement M = 251 car.,
  **contrepartie en ligne** (champ 56-63) → une seule ligne par opération, Quadra
  génère l'écriture inverse. Positions exactes documentées dans `quadra.py`.
- **FEC N-1 (684 lignes)** : lu sans erreur (tab, UTF-8, 18 colonnes). A révélé un
  **vrai bug** : les lignes « À-Nouveaux » faisaient croire à des imputations
  multiples (l'immo *et* son amortissement partagent le même libellé). Corrigé :
  on exclut le journal AN et les comptes d'amortissement/dépréciation (28/29).
  16 faux « multi » → 0.
- **3 factures (EDF, Brico Dépôt, Bouygues)** : lues ; ont fixé le contrat OCR
  (travailler sur l'image et pas la couche texte d'un ticket thermique ; TTC ≠
  espèces remises ; ignorer les blocs « EXEMPLE »). Détail dans `ocr.py`.

## Règles du cabinet intégrées

- **Comptabilité de trésorerie — le relevé fait foi.** C'est le mouvement
  bancaire qui définit ce qui est comptabilisé et à quelle date : une facture
  retrouvée en banque prend la **date du mouvement**, même si la pièce en
  annonçait une autre (et, réglée en plusieurs fois, la date du **dernier**
  règlement). Seule exception : une facture portant la mention « payée » qu'on ne
  retrouve pas en banque — écriture dans le **journal d'OD**, contrepartie
  **108**, **datée du jour du règlement**. Sans date de règlement sur la pièce,
  on retombe sur la date de facture **en le signalant** : jamais de date
  inventée en silence.
- **TVA (LMNP non assujetti, ≈90 % des cas)** : on comptabilise le **TTC en
  entier** en charge/immobilisation ; aucune écriture de TVA n'est jamais
  générée. La TVA d'une facture ne sert qu'à apprécier le seuil (en HT).
- **Seuil d'immobilisation = 500 € HT** : en dessous, un achat de nature durable
  (mobilier, bricolage, travaux) est passé **directement en charge** (auto) ;
  au-dessus, il reste **« à trancher »**. Le seuil s'apprécie en HT lorsque la
  facture donne la TVA, sinon sur le TTC (prudent).
  → conséquence sur le dossier test : le ticket Brico Dépôt (59,23 € HT) est
  **au-dessus** du seuil, donc remonté « à trancher ». Quand l'OCR lira le
  détail des lignes, les consommables (peinture, etc.) pourront être passés en
  entretien automatiquement quel que soit le montant.

## Démonstrations (sans donnée client)

```bash
python3 tool/demo/demo_sans_banque.py   # FEC N-1 -> dico -> 3 factures -> codage (ctp 108) -> Quadra OD
python3 tool/demo/demo_avec_banque.py   # relevé Quadra ASCII : lecture -> ré-export équilibré (ctp 512)
python3 tool/demo/demo_pipeline_complet.py  # BOUT-EN-BOUT : OCR -> codage -> à trancher (IA) -> à réclamer -> Quadra
python3 tool/demo/demo_3_factures.py    # les 3 vraies factures (valeurs OCR) du PDF à l'écriture Quadra
python3 tool/demo/demo_ingestion.py     # ingestion 'Drive' + idempotence : on n'OCR que les pièces neuves
python3 tool/demo/demo_pilotage.py      # revue analytique N-1 + relance (verrou) + tableau de bord cabinet
```

## Architecture proposée

```
FEC N-1 ─┐
         ├─► dico (dictionnaire client) ─┐
Relevé  ─┘                               ├─► codage ─► [revue humaine] ─► quadra ─► fichier d'import
Factures Drive ─► ocr (API Claude) ──────┘   rapprochement ─► manquants ─► mail de relance
```

Le **cœur est agnostique de la forme finale** (script en lot, Skill lancé dans
Claude Cowork, ou petite appli). Je recommande : **scripts Python + un Skill**
que Claude exécute dans Cowork — les collaborateurs ne voient que le résultat,
et les parties « montants » restent du code.

## Ce dont j'ai besoin de toi pour continuer

Les fichiers d'exemple et le format Quadra sont **reçus et intégrés**. Il reste :

1. ~~Accès API Anthropic~~ — **fait**. Le `ClientIA` réel est câblé
   (`client_anthropic.py`, Haiku 4.5 + escalade Sonnet 5), testé en réel sur la
   résolution d'ambiguïté et l'OCR. La clé se met dans `ANTHROPIC_API_KEY`
   (jamais dans le code). Sans clé, tout reste 100 % déterministe (couche IA =
   no-op). Le paquet `anthropic` n'est requis que pour ce fichier :
   `pip install anthropic` (le cœur du moteur reste stdlib pur).
2. **Doctrine d'immobilisation** : seuil (500 € HT ?) et règle entretien /
   amélioration. Aujourd'hui toute enseigne de bricolage/mobilier est remontée
   « à trancher » ; avec un seuil je pourrai auto-coder les petits achats
   (ex. le ticket Brico de 71 € → petit équipement) et ne garder en manuel que
   les vraies immo.
3. **Relevé bancaire non-Quadra** : si un client fournit un relevé Excel/CSV
   « brut » (et pas déjà au format Quadra), un exemplaire pour caler le lecteur.
4. **Deux décisions** : (a) forme finale (scripts + Skill dans Cowork, je pense) ;
   (b) modèle OCR par défaut (je propose Haiku 4.5, escalade Sonnet si doute).

## Les cas qui peuvent faire buguer (ce à quoi je fais déjà attention)

**Montants (zéro tolérance)** — séparateurs `,`/`.`/espace, négatifs, format
comptable `( )`, arrondis au centime. → `parse_montant` lève plutôt que
d'inventer ; contrôle d'équilibre débit=crédit à l'export.

**FEC** — délimiteur et encodage variables ; débit/crédit en 2 colonnes *ou*
montant+sens ; ordre des colonnes ; lignes A-Nouveau à exclure ; **le libellé
du FEC ≠ le libellé bancaire** (risque n°1 du rapprochement du dictionnaire).

**Relevé bancaire** — un format par banque ; montant signé *ou* deux colonnes ;
dates en série Excel *ou* texte ; lignes de totaux ; libellés tronqués.

**Codage** — fournisseur à imputations multiples en N-1 (géré : remonté) ;
immobilisation vs charge (remonté) ; échéance de prêt = **une** ligne bancaire à
ventiler 661/164 (nécessite le tableau d'amortissement en entrée) ; TVA ;
dépense mixte privé/pro (non déductible → à signaler).

**Rapprochement** — **un virement pour plusieurs factures**, paiement partiel,
remboursement (négatif), doublons (même montant 2×), **décalage de date**
facture/paiement, erreur d'OCR sur le montant → écart signalé, jamais corrigé.

**OCR** — photo floue/pivotée, plusieurs factures par PDF, multi-pages, ticket
thermique, langue étrangère, document qui n'est pas une facture, doublon,
**hallucination du montant** → le montant OCR ne sert qu'à rapprocher, jamais à
poster ; en dessous d'un seuil de confiance, la pièce est marquée « à revoir ».

**Quadra** — positions de champs à valider ; **compte inexistant** dans le
dossier → rejet ; folio déséquilibré → rejet ; encodage ISO-8859-1 ; caractères
spéciaux dans le libellé (nettoyés).

**Robustesse générale** — fichiers vides/mauvais type ; **idempotence /
pièces déjà traitées** (via un manifeste de suivi, pas en renommant les
fichiers du client) ; traçabilité (journaliser chaque décision + confiance +
qui a validé, pour la NPMQ) ; RGPD (données transmises à Anthropic → DPA) ;
locale `fr_FR`.

## Lancer les tests

```bash
python3 tool/tests/selftest.py          # 232 contrôles sur le moteur
```

Et les tests d'interface de la maquette (vrai navigateur, 78 contrôles) :

```bash
cd tool/tests/ui && npm install playwright-core
node audit.mjs && node audit2.mjs && node audit3.mjs && node verif.mjs && node export.mjs
```

Voir `tool/tests/ui/LISEZMOI.md`.
